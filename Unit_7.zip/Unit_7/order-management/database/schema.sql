-- Create database if not exists
CREATE DATABASE IF NOT EXISTS restaurant_order_db;
USE restaurant_order_db;

-- Drop tables if they exist (to avoid conflicts when re-importing)
DROP TABLE IF EXISTS food_items;
DROP TABLE IF EXISTS front_services;
DROP TABLE IF EXISTS table_services;

-- Create Food Items table
CREATE TABLE food_items (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    name VARCHAR(255) NOT NULL,
    description VARCHAR(255),
    price DOUBLE NOT NULL
);

-- Create Front Services table
CREATE TABLE front_services (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    customer_name VARCHAR(255) NOT NULL,
    order_details TEXT NOT NULL,
    status ENUM('Pending', 'Completed', 'Canceled') NOT NULL
);

-- Create Table Services table
CREATE TABLE table_services (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    table_number INT NOT NULL,
    status ENUM('Available', 'Reserved', 'Occupied') NOT NULL
);
