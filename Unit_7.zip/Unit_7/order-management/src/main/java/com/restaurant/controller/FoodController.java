package com.restaurant.controller;

import com.restaurant.model.FoodItem;
import com.restaurant.service.FoodService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/food") // Base endpoint for food-related operations
@CrossOrigin(origins = "http://localhost:4200") // Allow frontend access (adjust if needed)
public class FoodController {

    @Autowired
    private FoodService foodService; // Inject FoodService to handle business logic

    /**
     * Retrieve all food items.
     * @return List of all food items in the database.
     */
    @GetMapping
    public List<FoodItem> getAllFoodItems() {
        return foodService.getAllFoodItems();
    }

    /**
     * Retrieve a specific food item by its ID.
     * @param id The ID of the food item.
     * @return ResponseEntity with the food item or 404 if not found.
     */
    @GetMapping("/{id}")
    public ResponseEntity<FoodItem> getFoodItemById(@PathVariable Long id) {
        Optional<FoodItem> foodItem = foodService.getFoodItemById(id);
        return foodItem.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    /**
     * Add a new food item to the database.
     * @param foodItem The food item to be added.
     * @return ResponseEntity with the created food item.
     */
    @PostMapping
    public ResponseEntity<FoodItem> addFoodItem(@RequestBody FoodItem foodItem) {
        FoodItem createdFood = foodService.addFoodItem(foodItem);
        return ResponseEntity.ok(createdFood);
    }

    /**
     * Update an existing food item by its ID.
     * @param id The ID of the food item to be updated.
     * @param foodItem The updated food item data.
     * @return ResponseEntity with the updated food item.
     */
    @PutMapping("/{id}")
    public ResponseEntity<FoodItem> updateFoodItem(@PathVariable Long id, @RequestBody FoodItem foodItem) {
        FoodItem updatedFood = foodService.updateFoodItem(id, foodItem);
        return ResponseEntity.ok(updatedFood);
    }

    /**
     * Delete a food item by its ID.
     * @param id The ID of the food item to be deleted.
     * @return ResponseEntity with no content (204 status).
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteFoodItem(@PathVariable Long id) {
        foodService.deleteFoodItem(id);
        return ResponseEntity.noContent().build();
    }
}
