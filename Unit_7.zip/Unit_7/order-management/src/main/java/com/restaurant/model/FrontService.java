package com.restaurant.model;

import jakarta.persistence.*;

/**
 * Represents a front service order in the restaurant.
 */
@Entity
@Table(name = "front_services") // Maps to the "front_services" table in the database
public class FrontService {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) // Auto-increment primary key
    private Long id;

    @Column(nullable = false) // Ensures the column cannot be null
    private String customerName;

    @Column(nullable = false)
    private String orderDetails;

    @Column(nullable = false)
    private String status; // Possible values: "Pending", "Completed", "Canceled"

    /**
     * Default constructor (needed by JPA).
     */
    public FrontService() {}

    /**
     * Constructor to create a new FrontService order.
     * @param customerName The name of the customer.
     * @param orderDetails Details of the order.
     * @param status The status of the order.
     */
    public FrontService(String customerName, String orderDetails, String status) {
        this.customerName = customerName;
        this.orderDetails = orderDetails;
        this.status = status;
    }

    // Getters and Setters

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getOrderDetails() {
        return orderDetails;
    }

    public void setOrderDetails(String orderDetails) {
        this.orderDetails = orderDetails;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
