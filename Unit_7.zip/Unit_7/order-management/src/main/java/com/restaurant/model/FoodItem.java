package com.restaurant.model;

import jakarta.persistence.*;
import javafx.beans.property.*;

@Entity
@Table(name = "food_items")  // Ensure table name is correct
public class FoodItem {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) // Auto-generate ID
    private Long id;

    private String name;
    private String description;
    private Double price;

    // Default constructor (required by JPA)
    public FoodItem() {}

    // Constructor for creating objects
    public FoodItem(Long id, String name, String description, Double price) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.price = price;
    }

    public FoodItem(String name, String description, Double price) {
        this.name = name;
        this.description = description;
        this.price = price;
    }

    // Standard Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public Double getPrice() { return price; }
    public void setPrice(Double price) { this.price = price; }

    // JavaFX Properties for TableView
    public LongProperty idProperty() { return new SimpleLongProperty(id); }
    public StringProperty nameProperty() { return new SimpleStringProperty(name); }
    public StringProperty descriptionProperty() { return new SimpleStringProperty(description); }
    public DoubleProperty priceProperty() { return new SimpleDoubleProperty(price); }
}
