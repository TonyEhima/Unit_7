package com.restaurant.model;

import jakarta.persistence.*;

/**
 * Represents a table service in the restaurant.
 */
@Entity
@Table(name = "table_services") // Maps to the "table_services" table in the database
public class TableService {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) // Auto-increment primary key
    private Long id;

    @Column(nullable = false) // Ensures the column cannot be null
    private int tableNumber;

    @Column(nullable = false)
    private String status; // Possible values: "Available", "Reserved", "Occupied"

    /**
     * Default constructor (required by JPA).
     */
    public TableService() {}

    /**
     * Constructor to create a new table service record.
     * @param tableNumber The table number.
     * @param status The status of the table.
     */
    public TableService(int tableNumber, String status) {
        this.tableNumber = tableNumber;
        this.status = status;
    }

    // Getters and Setters

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public int getTableNumber() {
        return tableNumber;
    }

    public void setTableNumber(int tableNumber) {
        this.tableNumber = tableNumber;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
