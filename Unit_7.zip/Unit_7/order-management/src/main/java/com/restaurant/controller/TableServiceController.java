package com.restaurant.controller;

import com.restaurant.model.TableService;
import com.restaurant.service.TableServiceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/tableservices") // Base endpoint for table service operations
@CrossOrigin(origins = "http://localhost:4200") // Allow frontend access (adjust if needed)
public class TableServiceController {

    @Autowired
    private TableServiceService tableServiceService; // Inject TableServiceService to handle business logic

    /**
     * Retrieve all table service records.
     * @return List of all tables.
     */
    @GetMapping
    public List<TableService> getAllTables() {
        return tableServiceService.getAllTables();
    }

    /**
     * Retrieve a specific table by its ID.
     * @param id The ID of the table.
     * @return ResponseEntity with the table or 404 if not found.
     */
    @GetMapping("/{id}")
    public ResponseEntity<TableService> getTableById(@PathVariable Long id) {
        Optional<TableService> table = tableServiceService.getTableById(id);
        return table.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    /**
     * Add a new table service record.
     * @param tableService The table service data to be added.
     * @return ResponseEntity with the created table.
     */
    @PostMapping
    public ResponseEntity<TableService> addTable(@RequestBody TableService tableService) {
        TableService createdTable = tableServiceService.addTable(tableService);
        return ResponseEntity.ok(createdTable);
    }

    /**
     * Update an existing table service record by its ID.
     * @param id The ID of the table to be updated.
     * @param tableService The updated table service data.
     * @return ResponseEntity with the updated table.
     */
    @PutMapping("/{id}")
    public ResponseEntity<TableService> updateTable(@PathVariable Long id, @RequestBody TableService tableService) {
        TableService updatedTable = tableServiceService.updateTable(id, tableService);
        return ResponseEntity.ok(updatedTable);
    }

    /**
     * Delete a table service record by its ID.
     * @param id The ID of the table to be deleted.
     * @return ResponseEntity with no content (204 status).
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteTable(@PathVariable Long id) {
        tableServiceService.deleteTable(id);
        return ResponseEntity.noContent().build();
    }
}
